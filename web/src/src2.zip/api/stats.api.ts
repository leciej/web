import { http } from "./http";

/* =========================================
   ===== ADMIN / PLATFORM STATS =====
   ========================================= */

export interface PlatformStatsDto {
  purchasedCount: number;
  totalSpent: number;
  ratedCount: number;
  averageRating: number;
  commentsCount: number;
  activitiesCount: number;
}

export function getPlatformStats() {
  return http.get<PlatformStatsDto>("/api/stats/platform");
}

/* ===== ORDERS CHART (LAST 7 DAYS) ===== */

export interface OrdersChartDto {
  days: string[];
  orders: number[];
  revenue: number[];
}

export function getOrdersLast7Days() {
  return http.get<OrdersChartDto>("/api/stats/orders-last-7-days");
}

/* =========================================
   ===== USER STATS & ACTIVITY =====
   (To dodajemy dla Profilu Użytkownika)
   ========================================= */

export interface UserStatsDto {
  purchasedCount: number;
  totalSpent: number;
  ratedCount: number;
  averageRating: number;
  commentsCount: number;
}

// Pobieranie statystyk konkretnego usera
export function getUserStats(userId: number) {
  return http.get<UserStatsDto>(`/api/users/${userId}/stats`);
}

/* ===== ACTIVITY LOG ===== */

export interface ActivityDto {
  type: string;
  createdAt: string;
  targetType?: string;
  message?: string;
}

export interface ActivityResponseDto {
  items: ActivityDto[];
}

// Pobieranie aktywności (np. historia koszyka, ocen)
export function getUserActivity(userId: number) {
  // Przekazujemy userId jako parametr query: /api/activity?userId=...
  return http.get<ActivityResponseDto>("/api/activity", { userId });
}