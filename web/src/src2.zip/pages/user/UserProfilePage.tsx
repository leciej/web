import { useEffect, useState, useSyncExternalStore } from "react";
import { useNavigate } from "react-router-dom";
import { useUser } from "../../context/UserContext";

// Importujemy STORE (tak jak u Admina) zamiast api/activity
import {
  subscribe,
  getActivities,
  type Activity,
} from "../../features/activityStore";

// Statystyki nadal pobieramy z API (bo store nie trzyma historii wydatków)
import { getUserStats, type UserStatsDto } from "../../api/stats.api";

/* =========================
   HELPERS
   ========================= */

// Filtrujemy tylko akcje użytkownika (żeby nie widział np. edycji produktu przez admina)
const isUserType = (type: string): boolean =>
  [
    "ADD_TO_CART",
    "REMOVE_FROM_CART",
    "PURCHASE",
    "RATING",
    "COMMENT",
  ].includes(type);

const label = (type: string): string =>
  ({
    ADD_TO_CART: "➕ Dodano do koszyka",
    REMOVE_FROM_CART: "🗑 Usunięto z koszyka",
    PURCHASE: "🛒 Złożono zamówienie",
    RATING: "⭐ Oceniono produkt",
    COMMENT: "💬 Dodano komentarz",
  }[type] ?? "— Aktywność");

function timeAgo(timestamp: number): string {
  const diff = Date.now() - timestamp;
  const min = Math.floor(diff / 60000);

  if (min < 1) return "przed chwilą";
  if (min < 60) return `${min} min temu`;

  const h = Math.floor(min / 60);
  if (h < 24) return `${h} h temu`;
  
  return new Date(timestamp).toLocaleDateString();
}

/* =========================
   COMPONENT
   ========================= */

export default function UserProfilePage() {
  const { user, logout } = useUser();
  const navigate = useNavigate();

  const [stats, setStats] = useState<UserStatsDto | null>(null);

  // === 1. POBIERANIE AKTYWNOŚCI ZE STORE (jak u Admina) ===
  const activities = useSyncExternalStore(
    subscribe,
    getActivities
  )
    .filter((a: Activity) => isUserType(a.type)) // Filtrujemy tylko nasze akcje
    .reverse() // Najnowsze na górze (store trzyma chronologicznie, więc odwracamy)
    .slice(0, 5); // Pokaż 5 ostatnich

  // === 2. DANE UŻYTKOWNIKA ===
  const email = user?.email ?? "user@local";
  const displayName = user?.login || email.split("@")[0];
  const letter = displayName[0]?.toUpperCase() ?? "U";

  // === 3. POBIERANIE STATYSTYK Z BAZY (To zostawiamy, bo to trwałe dane) ===
  useEffect(() => {
    if (!user?.id) return;
    getUserStats(user.id)
      .then(setStats)
      .catch(() => setStats(null));
  }, [user?.id]);

  const handleLogout = () => {
    logout();
    navigate("/", { replace: true });
  };

  const handleBack = () => {
    navigate("/user/dashboard");
  };

  return (
    <div className="admin-root">
      <div className="admin-grid-2x2">
        
        {/* KAFEL 1: PROFIL */}
        <div className="admin-block glass">
          <div className="admin-profile">
            <div className="admin-avatar">{letter}</div>
            <div className="admin-name">{displayName}</div>
            <div className="admin-email">{email}</div>
            <div className="admin-role">👤 Użytkownik</div>
          </div>
        </div>

        {/* KAFEL 2: OSTATNIA AKTYWNOŚĆ (Ze Store'a) */}
        <div className="admin-block glass">
          <h2>Ostatnia aktywność</h2>

          {activities.length === 0 ? (
            <p className="muted">Brak ostatniej aktywności</p>
          ) : (
            <ul style={{ paddingLeft: 16 }}>
              {activities.map((a: Activity, i: number) => (
                <li key={i} style={{ fontSize: 13, marginBottom: 8 }}>
                  {label(a.type)}
                  <div style={{ fontSize: 11, opacity: 0.6 }}>
                    {timeAgo(a.createdAt)}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* KAFEL 3: STATYSTYKI (Z API) */}
        <div className="admin-block glass">
          <h2>Twoje statystyki</h2>

          {!stats ? (
            <p className="muted">Ładowanie danych...</p>
          ) : (
            <div style={{ fontSize: 14, lineHeight: 1.8 }}>
              <div>✅ Kupione produkty: <strong>{stats.purchasedCount}</strong></div>
              <div>💸 Wydane pieniądze: <strong>{stats.totalSpent.toFixed(2)} zł</strong></div>
              <div>⭐ Ocenione: <strong>{stats.ratedCount}</strong></div>
              <div>💬 Komentarze: <strong>{stats.commentsCount}</strong></div>
            </div>
          )}
        </div>

        {/* KAFEL 4: NAWIGACJA */}
        <div className="admin-block glass center">
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "18px",
              width: "100%",
            }}
          >
            <button
              className="admin-action big secondary full"
              onClick={handleBack}
            >
              ← Wróć do pulpitu
            </button>

            <button
              className="admin-logout"
              onClick={handleLogout}
            >
              WYLOGUJ SIĘ
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}