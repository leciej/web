import { useContext } from 'react';
import { UserContext } from './UserContext';
import type { UserContextType } from './UserContext';

export function useUser(): UserContextType {
  const ctx = useContext(UserContext);
  if (!ctx) {
    throw new Error('useUser must be used inside UserProvider');
  }
  return ctx;
}
