import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';

import { getProduct } from '../api/products.api';
import type { ProductDto } from '../api/products.api';

import {
  getProductComments,
  addProductComment,
  type CommentDto,
} from '../api/comments.api';

import { addToCart } from '../api/cart.api';
import { useUser } from '../context/useUser';

export default function ProductDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const { user } = useUser();

  const [product, setProduct] = useState<ProductDto | null>(null);
  const [comments, setComments] = useState<CommentDto[]>([]);
  const [commentText, setCommentText] = useState('');
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (!id) return;

    getProduct(id)
      .then(setProduct)
      .catch(() => setFailed(true));

    getProductComments(id)
      .then(setComments)
      .catch(() => {
        /* brak komentarzy ≠ błąd strony */
      });
  }, [id]);

  if (!id) return <p>Brak ID produktu</p>;
  if (failed) return <p>Błąd ładowania produktu</p>;
  if (!product) return <p>Ładowanie…</p>;

  return (
    <div>
      <Link to="/products">← Wróć do produktów</Link>

      <h1>{product.name}</h1>

      {product.imageUrl && (
        <img
          src={product.imageUrl}
          alt={product.name ?? 'Produkt'}
          style={{ maxWidth: 300 }}
        />
      )}

      <p>{product.description}</p>
      <p>
        <strong>{product.price} zł</strong>
      </p>

      <button
        disabled={!user}
        onClick={() => addToCart(product.id!, user!.id)}
      >
        Dodaj do koszyka
      </button>

      {!user && <p>Zaloguj się, aby dodać do koszyka</p>}

      <hr />

      <h2>Komentarze</h2>

      {comments.length === 0 && <p>Brak komentarzy</p>}

      {comments.map(c => (
        <div
          key={c.id}
          style={{ borderBottom: '1px solid #444', marginBottom: 8 }}
        >
          <strong>{c.author ?? 'Anonim'}</strong>
          <p>{c.text}</p>
          <small>
            {new Date(c.createdAt).toLocaleString()}
          </small>
        </div>
      ))}

      {user && (
        <div>
          <textarea
            value={commentText}
            onChange={e => setCommentText(e.target.value)}
            placeholder="Dodaj komentarz"
          />

          <br />

          <button
            disabled={!commentText.trim()}
            onClick={() => {
              addProductComment(product.id!, user.id, commentText)
                .then(() => getProductComments(product.id!))
                .then(setComments);

              setCommentText('');
            }}
          >
            Dodaj komentarz
          </button>
        </div>
      )}
    </div>
  );
}
