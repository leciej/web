import { Link } from 'react-router-dom';

export default function SplashPage() {
  return (
    <div style={{ padding: 40 }}>
      <h1>SPLASH</h1>

      <Link to="/login">
        <button style={{ padding: 12 }}>
          PRZEJDŹ DO LOGIN
        </button>
      </Link>
    </div>
  );
}
