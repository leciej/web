import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createGuest, login } from '../api/users.api';
import { useUser } from '../context/useUser';

export default function LoginPage() {
  const navigate = useNavigate();
  const { setUser } = useUser();

  const [loginOrEmail, setLoginOrEmail] = useState('');
  const [password, setPassword] = useState('');

  return (
    <div style={styles.container}>
      <h2>Guten Tag twoja mać!</h2>

      <button
        style={styles.guest}
        onClick={async () => {
          const user = await createGuest();
          setUser(user);
          navigate('/products');
        }}
      >
        Zaloguj jako gość
      </button>

      <button style={styles.user}>
        Zaloguj jako użytkownik
      </button>

      <input
        placeholder="Login lub email"
        value={loginOrEmail}
        onChange={e => setLoginOrEmail(e.target.value)}
        style={styles.input}
      />

      <input
        placeholder="Hasło"
        type="password"
        value={password}
        onChange={e => setPassword(e.target.value)}
        style={styles.input}
      />

      <button
        style={styles.primary}
        onClick={async () => {
          const user = await login(loginOrEmail, password);
          setUser(user);
          navigate('/products');
        }}
      >
        Zaloguj
      </button>

      <button
        style={styles.admin}
        onClick={async () => {
          const user = await login(loginOrEmail, password);
          setUser(user);
          navigate('/admin');
        }}
      >
        Zaloguj jako admin
      </button>

      <button
        style={styles.register}
        onClick={() => navigate('/register')}
      >
        Zarejestruj się
      </button>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    maxWidth: 420,
    margin: '40px auto',
    display: 'flex',
    flexDirection: 'column',
    gap: 12,
  },
  input: {
    padding: 12,
    fontSize: 14,
  },
  primary: {
    padding: 12,
    background: '#1976d2',
    color: '#fff',
    border: 'none',
  },
  guest: {
    padding: 12,
    background: '#00897b',
    color: '#fff',
    border: 'none',
  },
  admin: {
    padding: 12,
    background: '#455a64',
    color: '#fff',
    border: 'none',
  },
  register: {
    padding: 12,
    background: '#2e7d32',
    color: '#fff',
    border: 'none',
  },
  user: {
    padding: 12,
    background: '#1976d2',
    color: '#fff',
    border: 'none',
  },
};
