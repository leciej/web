export default function AdminGalleryPage() {
  return (
    <div>
      <h1>Admin – Arcydzieła</h1>
      <p>Zarządzanie galerią</p>
    </div>
  );
}
