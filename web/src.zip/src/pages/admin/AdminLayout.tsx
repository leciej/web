import { Navigate, Outlet } from 'react-router-dom';
import { useUser } from '../../context/useUser';

export default function AdminLayout() {
  const { user } = useUser();

  if (user?.role !== 'Admin') {
    return <Navigate to="/" replace />;
  }

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <aside style={{ width: 200, padding: 16, borderRight: '1px solid #ccc' }}>
        ADMIN
      </aside>
      <main style={{ flex: 1, padding: 16 }}>
        <Outlet />
      </main>
    </div>
  );
}
