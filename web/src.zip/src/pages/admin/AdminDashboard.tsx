import { useUser } from '../../context/useUser';

export default function AdminDashboard() {
  const { user } = useUser();

  if (user?.role !== 'Admin') {
    return <p>Brak dostępu</p>;
  }

  return <h1>Panel administratora</h1>;
}
