export default function AdminProfilePage() {
  return (
    <div>
      <h1>Profil administratora</h1>
      <p>Dane konta admina</p>
    </div>
  );
}
