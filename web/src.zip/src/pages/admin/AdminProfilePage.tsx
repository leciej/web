export default function AdminProfilePage() {
  return (
    <div>
      <h1>Profil administratora</h1>

      <p>Tu będą dane konta admina</p>

      <ul>
        <li>Zmiana hasła</li>
        <li>Zmiana danych</li>
        <li>Wylogowanie</li>
      </ul>
    </div>
  );
}
