import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { register } from '../api/users.api';

export default function RegisterPage() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: '',
    surname: '',
    login: '',
    email: '',
    password: '',
    repeat: '',
  });

  return (
    <div style={styles.container}>
      <h2>Rejestracja</h2>

      <input placeholder="Imię" onChange={e => setForm({ ...form, name: e.target.value })} />
      <input placeholder="Nazwisko" onChange={e => setForm({ ...form, surname: e.target.value })} />
      <input placeholder="Login" onChange={e => setForm({ ...form, login: e.target.value })} />
      <input placeholder="Email" onChange={e => setForm({ ...form, email: e.target.value })} />
      <input type="password" placeholder="Hasło" onChange={e => setForm({ ...form, password: e.target.value })} />
      <input type="password" placeholder="Powtórz hasło" onChange={e => setForm({ ...form, repeat: e.target.value })} />

      <button
        style={styles.primary}
        onClick={async () => {
          await register(form);
          navigate('/login');
        }}
      >
        Zarejestruj
      </button>

      <button style={styles.back} onClick={() => navigate('/login')}>
        Wróć
      </button>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    maxWidth: 420,
    margin: '40px auto',
    display: 'flex',
    flexDirection: 'column',
    gap: 12,
  },
  primary: {
    padding: 12,
    background: '#1976d2',
    color: '#fff',
    border: 'none',
  },
  back: {
    padding: 12,
    background: '#455a64',
    color: '#fff',
    border: 'none',
  },
};
