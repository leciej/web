import { http } from './http';

/* ========= DTO ========= */

export interface ProductDto {
  id: string;
  name: string;
  description?: string | null;
  price: number;
  imageUrl?: string | null;
}

export interface CreateProductRequest {
  name: string;
  description?: string;
  price: number;
  imageUrl?: string;
}

export interface UpdateProductRequest {
  name?: string;
  description?: string;
  price?: number;
  imageUrl?: string;
}

/* ========= QUERIES ========= */

export function getProducts() {
  return http.get<ProductDto[]>('/api/products');
}

export function getProduct(id: string) {
  return http.get<ProductDto>(`/api/products/${id}`);
}

/* ========= COMMANDS (ADMIN) ========= */

export function createProduct(
  data: CreateProductRequest,
  actorUserId?: number
) {
  return http.post<ProductDto>(
    '/api/products',
    data,
    actorUserId ? { actorUserId } : undefined
  );
}

export function updateProduct(
  id: string,
  data: UpdateProductRequest,
  actorUserId?: number
) {
  return http.patch<void>(
    `/api/products/${id}`,
    data,
    actorUserId ? { actorUserId } : undefined
  );
}

export function deleteProduct(
  id: string,
  actorUserId?: number
) {
  return http.delete<void>(
    `/api/products/${id}`,
    actorUserId ? { actorUserId } : undefined
  );
}
