import { http } from './http';

export interface PlatformStatsDto {
  purchasedCount: number;
  totalSpent: number;
  ratedCount: number;
  averageRating: number;
  commentsCount: number;
  activitiesCount: number;
}

export function getPlatformStats() {
  return http.get<PlatformStatsDto>('/api/stats/platform');
}

export function getOrdersLast7Days() {
  return http.get('/api/stats/orders-last-7-days');
}
