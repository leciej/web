import { http } from './http';

/* ========= DTO ========= */

export interface GalleryItemDto {
  id: string;
  title?: string;
  artist?: string;
  price: number;
  imageUrl?: string;
}

export interface GalleryRatingSummaryDto {
  average: number;
  votes: number;
  myRating?: number | null;
}

/* ========= ITEMS ========= */

export function getGallery() {
  return http.get<GalleryItemDto[]>('/api/gallery');
}

export function getGalleryItem(id: string) {
  return http.get<GalleryItemDto>(`/api/gallery/${id}`);
}

/* ========= RATINGS ========= */

export function getGalleryRating(
  id: string,
  userId?: number
) {
  return http.get<GalleryRatingSummaryDto>(
    `/api/gallery/${id}/ratings`,
    userId ? { userId } : undefined
  );
}

export function rateGalleryItem(
  id: string,
  userId: number,
  value: number
) {
  return http.post<void>(
    `/api/gallery/${id}/ratings`,
    { userId, value }
  );
}
